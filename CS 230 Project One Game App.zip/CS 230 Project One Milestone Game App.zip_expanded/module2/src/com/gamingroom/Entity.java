/**
 * A class to represent an entity with a unique identifier and name
 * 
 * Edited By: Darrell Walker 07/20/2024
 */

package com.gamingroom;

public abstract class Entity {
    protected long id;
    protected String name;

    // Custom constructor with id & name params
    protected Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Entity [id=" + id + ", name=" + name + "]";
    }
}