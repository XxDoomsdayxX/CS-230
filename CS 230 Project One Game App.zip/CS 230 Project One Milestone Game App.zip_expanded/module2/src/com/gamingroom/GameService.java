package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 * 
 * Edited By: Darrell Walker 07/20/2024
 * 
 * The Singleton pattern is used to make sure that only one instance of the GameService class
 * exists throughout the entire application. This is important because we want to have a single
 * point of access to manage all the games. It helps keep things consistent and prevents creating
 * multiple game services by mistake.
 * 
 * Characteristics of the Singleton pattern:
 * 1. **Single Instance**: Only one instance of the class is created and used in the whole application.
 * 2. **Global Access**: Provides a way to access this single instance from anywhere in the application.
 * 3. **Lazy Initialization**: The instance is created only when it is needed for the first time.
 * 4. **Thread Safety**: Ensures that the instance is safely created when multiple threads are used (advanced topic).
 * 
 * @version 1.0
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// Add missing pieces to turn this class a singleton 
	// The single instance of the class
	private static GameService instance;
	
	// Private constructor to prevent instantiation
	private GameService() {}
	
	// Public method to provide access to the instance
	public static GameService getInstance() {
	       if (instance == null) {
	           instance = new GameService();
	       }
	       return instance;
	}

	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		Game game = getGame(name);

        if (game == null) {
            game = new Game(nextGameId++, name);
            games.add(game);
        }

        return game;
    }

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		for (Game game : games) {
            if (game.getId() == id) {
                return game;
            }
        }
        return null;
    }


	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {
		if (name == null) {
            return null;
        }
        for (Game game : games) {
            if (game.getName() != null && game.getName().equals(name)) {
                return game;
            }
        }
        return null;
    }

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
